# A simple Android calculator app

demo https://youtu.be/7pL_yyCI1xg

Nothing special, I just made a very simple calculator app for android phones.   



This Calculator app is an application developed for android cells phones and tablets. It enables the users to perform fundamental mathematical operations such as addition, subtraction, multiplication and division on their phone. Being installed on phone, it always remains with the user, helps in daily life calculations and works as a typical android calculator app.
<h3>Android Studio latest free projects with source code</h3>
Below, I have briefly described the features and scopes of Calculator Android app along with a point-wise comparison with existing calculators. You can download the source code and project files from the download links in this post. The source code is complete and error-free.

Fundamental mathematical calculations are required to be performed in every step of human life. In most of the places such as in shops, hotels, medicals, schools etc., separate calculators are used for calculation. But, these calculators, being larger in size and needing extra power, can’t be carried all the time with us. This creates the necessity of a mobile calculator which is always with us.

Since android applications are the most compatible ones and easily available, android cell phones and tablets are the most widely used devices all over the world. They offer several kinds of facilities and one of them is calculator which is fundamental application of each phone. Looking at the growing use of android phones, it can be said that a Calculator app as Android Project has good scope in today’s technological world.

<strong>Comparison:</strong>

The comparison between existing traditional calculators and the proposed Calculator app for Android can be done in the following points:
<ol>
 	<li><strong>Size</strong>: The separate calculators are larger in size due to use of own circuit board whereas android calculator is installed in cell phones.</li>
 	<li><strong>Power</strong>: A small battery power of cell phone is enough for running android calculator but traditional calculator consume comparatively higher power.</li>
 	<li><strong>Accuracy</strong>: The accuracy of both the calculators depends upon their programming. Calculators can be designed for the desired accuracy.</li>
 	<li><strong>Cost</strong>: Android Calculator, being an application, can be downloaded free of cost and installed on phone. The traditional calculators have their own hardware. As a result of this, they need to be purchased.</li>
 	<li><strong>Ease and comfort</strong>: Most of the android cell phones are of touch screen type. So, calculator app Android is easy and comfortable to use.</li>
</ol>
<strong>Features:</strong>
<ul>
 	<li>It is easy and comfortable to use.</li>
 	<li>The application can be easily downloaded and installed on any android cell phone and tablet.</li>
 	<li>It provides the facility to perform fundamental mathematical operations.</li>
 	<li>The application gives fast and accurate result.</li>
 	<li>This application consumes very small power of your cell phone.</li>
</ul>
<h3 id="requirement" class="notes">Software Requirement</h3>
<ul>
 	<li>Android Studio  : version 3.3 latest</li>
 	<li>Latest Version</li>
 	<li>Internet Connection</li>
 	<li>Java</li>
</ul>
&nbsp;

